import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.Test;

public class TestVector {

    private static final double EPSILON = 0.000001;

    private static boolean equals(double d1, double d2) {
        if (d1 - d2 < 0.0001) {
            return true;
        } else {
            return false;
        }
    }

    @Test
    public void testEmptyConstructor() {
        double[] components = new double[2];
        double[] expected = { 1.0, 1.0 };
        components[0] = 1;
        components[1] = 1;
        Vector v = new Vector(components);
        assertTrue(Arrays.equals(expected, v.getComponents()));
        assertEquals(Math.sqrt(2), v.getMagnitude(), EPSILON);
    }

    @Test
    public void testAddZeroVector() {
        Vector expected = new Vector(new double[] { 1, 1 });
        Vector zeroVec = new Vector(new double[] { 0, 0 });
        Vector v = new Vector(new double[] { 1, 1 });
        v.add(zeroVec);
        assertTrue(expected.equals(v));
    }

    @Test
    public void testAdd() {
        Vector addVec = new Vector(new double[] { 2, 3 });
        Vector v = new Vector(new double[] { 1, 1 });
        Vector expected = new Vector(new double[] { 3, 4 });
        v.add(addVec);
        assertTrue(expected.equals(v));
    }

    @Test
    public void testAddNegative() {
        Vector addVec = new Vector(new double[] { -2, -3 });
        Vector v = new Vector(new double[] { 1, 1 });
        v.add(addVec);
        Vector expectedV = new Vector(new double[] { -1, -2 });
        assertTrue(expectedV.equals(v));
    }

    @Test
    public void testReverse() {
        Vector v = new Vector(new double[] { 1, 1 });
        Vector expected = new Vector(new double[] { -1, -1 });
        v.reverseDirection();
        assertTrue(Arrays.equals(new double[] { -1, -1 }, v.getComponents()));
    }

    @Test
    public void testEquals() {
        Vector v = new Vector(new double[] { 1, 1 });
        Vector u = new Vector(new double[] { 1, 1 });
        assertTrue(v.equals(u));
    }

    @Test
    public void testDoubleEquality() {
        double f1 = .0;
        for (int i = 1; i <= 11; i++) {
            f1 += .1;
        }

        double f2 = .1 * 11;

        double[] arr1 = new double[1];
        arr1[0] = f1;
        Vector v1 = new Vector(arr1);

        double[] arr2 = new double[1];
        arr2[0] = f2;
        Vector v2 = new Vector(arr2);

        assertTrue(v1.equals(v2));
    }

    @Test
    public void testToString() {
        Vector v = new Vector(new double[] { -4.35666, 23421, 2391.1, 3 });
        assertEquals("<-4.35666, 23421.0, 2391.1, 3.0>", v.toString());
    }

    @Test
    public void testMultiplyScalar() {
        Vector v = new Vector(new double[] { 1, 2, 3, 4, 5 });
        Vector expected = new Vector(new double[] { 4, 8, 12, 16, 20 });
        v.multiplyScalar(4);
        assertTrue(v.equals(expected));
    }

    @Test(expected = java.lang.AssertionError.class)
    public void testDotProductExpectedAssertionError() {
        Vector v = new Vector(new double[] { 1, 2, 3 });
        Vector u = new Vector(new double[] { 1, 2 });
        assertTrue(TestVector.equals(-1, Vector.dotProduct(v, u)));
    }

    @Test
    public void testDotProductEasy() {
        Vector v = new Vector(new double[] { 1, 2, 3 });
        Vector u = new Vector(new double[] { 1, 2, 4 });
        assertTrue(TestVector.equals(17, Vector.dotProduct(v, u)));
    }

    @Test
    public void testDotProductWithNegatives() {
        Vector v = new Vector(new double[] { -1, 2, 3 });
        Vector u = new Vector(new double[] { 1, -2, 3 });
        assertTrue(TestVector.equals(4, Vector.dotProduct(v, u)));
    }

    @Test
    public void testDotProductWithDecimals() {
        Vector v = new Vector(new double[] { 1.1, 2.2, 3.3 });
        Vector u = new Vector(new double[] { 3.56, 12.3, 1.5 });
        assertTrue(TestVector.equals(35.926, Vector.dotProduct(v, u)));
    }

    @Test
    public void testDotProductSelf() {
        Vector v = new Vector(new double[] { 1, 2 });
        assertTrue(TestVector.equals(5, Vector.dotProduct(v, v)));
    }

    @Test
    public void testCrossProductEasy() {
        Vector v = new Vector(new double[] { 1, 2, 3 });
        Vector u = new Vector(new double[] { 1, 2, 5 });
        Vector vCrossU = Vector.crossProduct(v, u);
        Vector expected = new Vector(new double[] { 4, -2, 0 });
        assertTrue(vCrossU.equals(expected));
    }

    @Test(expected = AssertionError.class)
    public void testCrossProductDifferentLengths() {
        Vector v = new Vector(new double[] { 1, 2 });
        Vector u = new Vector(new double[] { 1 });
        Vector vCrossU = Vector.crossProduct(v, u);
    }

    @Test
    public void testIsOrthogonal() {
        Vector v = new Vector(new double[] { 1, 6, 7 });
        Vector u = new Vector(new double[] { 1, 1, -1 });
        assertTrue(v.isOrthogonalTo(u));
    }

    @Test
    public void testIsOrthogonalFalse() {
        Vector v = new Vector(new double[] { 1, 6, 7 });
        Vector u = new Vector(new double[] { 1, 1, 1 });
        assertFalse(v.isOrthogonalTo(u));
    }

    @Test
    public void testAngleBetween2Dimensions() {
        Vector v = new Vector(new double[] { 1, 0 });
        Vector u = new Vector(new double[] { 0, 1 });
        assertEquals(Math.PI / 2, v.angleBetween(u), EPSILON);
    }

    @Test
    public void testAngleBetween3Dimensions() {
        Vector v = new Vector(new double[] { 1, 6, 7 });
        Vector u = new Vector(new double[] { 1, 1, -1 });
        assertEquals(Math.PI / 2, v.angleBetween(u), EPSILON);
    }

    @Test
    public void testGetUnitVector() {
        Vector v = new Vector(new double[] { 0, 1 });
        Vector expected = new Vector(new double[] { 0, 1 });
        Vector unitVec = v.getUnitVector();
        assertTrue(unitVec.equals(expected));
    }

    @Test
    public void testGetUnitVector2() {
        Vector v = new Vector(new double[] { 0, 3 });
        Vector expected = new Vector(new double[] { 0, 1 });
        Vector unitVec = v.getUnitVector();
        assertTrue(unitVec.equals(expected));
    }

    @Test
    public void testGetUnitVector2D() {
        Vector v = new Vector(new double[] { 3.5, -1.8 });
        Vector expected = new Vector(new double[] { 0.8892878, -0.457348 });
        Vector unitVec = v.getUnitVector();
        assertTrue(unitVec.equals(expected));
    }

    @Test
    public void testGetUnitVector3D() {
        Vector v = new Vector(new double[] { 1.2, 5.3, 7.3 });
        Vector expected = new Vector(
                new double[] { 0.13186017, 0.5823824, 0.80214937 });
        Vector unitVec = v.getUnitVector();
        assertTrue(unitVec.equals(expected));
    }

    @Test
    public void testParallel() {
        Vector v = new Vector(new double[] { 2, 4, 6 });
        Vector u = new Vector(new double[] { 4, 8, 12 });
        assertTrue(v.isParallelTo(u));
    }

    @Test
    public void testParallel2() {
        Vector v = new Vector(new double[] { 0, 1 });
        Vector u = new Vector(new double[] { 0, -1 });
        assertTrue(v.isParallelTo(u));
    }

    @Test
    public void testParallel3() {
        Vector v = new Vector(new double[] { 0, 0, 1 });
        Vector u = new Vector(new double[] { 0, 0, -1 });
        assertTrue(v.isParallelTo(u));
    }

    @Test
    public void testParallel4() {
        Vector v = new Vector(new double[] { 1, 2, 3, 4 });
        Vector u = new Vector(new double[] { -1, -2, -3, -4 });
        assertTrue(v.isParallelTo(u));
    }

}
