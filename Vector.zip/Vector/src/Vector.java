import java.util.Arrays;

public class Vector {
    private double magnitude;
    private double[] components;

    public Vector(double[] components) {
        assert components != null : "Components must not be null";
        assert components.length != 0 : "Vector dimension must be > 0";
        this.components = components;
        this.updateMagnitude();
    }

    public void add(Vector v) {
        assert v != null : "Vector to be added cannot be null";
        assert this.components.length == v.components.length : "Vectors in different dimensions";
        for (int i = 0; i < v.components.length; i++) {
            this.components[i] += v.components[i];
        }
        this.updateMagnitude();
    }

    public void subtract(Vector v) {
        assert v != null : "Vector to be subtracted cannot be null";
        v.reverseDirection();
        this.add(v);
        v.reverseDirection();
    }

    public void multiplyScalar(int s) {
        for (int i = 0; i < this.components.length; i++) {
            this.components[i] *= s;
        }
        this.magnitude *= Math.abs(s);
    }

    public void reverseDirection() {
        this.multiplyScalar(-1);
    }

    public boolean isOrthogonalTo(Vector v) {
        return Vector.equals(0, Vector.dotProduct(this, v));
    }

    // If unit vector of this is equal to the unit vector of v, or
    // if the unit vector of this is equal to the reversed direction unit vector of v,
    // then the vectors are parallel.
    // TODO: (for Vector3D) by cross product
    public boolean isParallelTo(Vector v) {
        assert this.components.length == v.components.length;
        Vector thisUnitVec = this.getUnitVector();
        Vector vUnitVec = v.getUnitVector();

        boolean isParallel = thisUnitVec.equals(vUnitVec);
        vUnitVec.reverseDirection();
        isParallel |= thisUnitVec.equals(vUnitVec);
        return isParallel;
    }

    public Vector getUnitVector() {
        double[] unitVectorComponents = Arrays.copyOf(this.components,
                this.components.length);
        for (int i = 0; i < unitVectorComponents.length; i++) {
            unitVectorComponents[i] /= this.magnitude;
        }
        return new Vector(unitVectorComponents);
    }

    // in rad
    public double angleBetween(Vector v) {
        // this dot v = |this||v|cos(angle);
        double dotProduct = Vector.dotProduct(this, v);
        double thisMag = this.getMagnitude();
        double vMag = v.getMagnitude();
        return Math.acos(dotProduct / (thisMag * vMag));
    }

    public static double dotProduct(Vector v, Vector u) {
        assert v.components.length == u.components.length : "For dot product, vectors must be equal dimensions";
        double dotProduct = 0;
        for (int i = 0; i < v.components.length; i++) {
            dotProduct += v.components[i] * u.components[i];
        }
        return dotProduct;
    }

    public static Vector crossProduct(Vector v, Vector u) {
        double[] vComp = v.components;
        assert vComp.length == 3;
        double[] uComp = u.components;
        assert uComp.length == 3;

        double i = vComp[1] * uComp[2] - vComp[2] * uComp[1];
        double j = vComp[2] * uComp[0] - vComp[0] * uComp[2];
        double k = vComp[0] * uComp[1] - vComp[1] * uComp[0];

        double[] components = new double[] { i, j, k };
        return new Vector(components);
    }

    public double getMagnitude() {
        return this.magnitude;
    }

    public double[] getComponents() {
        return this.components;
    }

    @Override
    public String toString() {
        String s = "<" + this.components[0];
        for (int i = 1; i < this.components.length; i++) {
            s += ", " + this.components[i];
        }
        return s += ">";
    }

    public boolean equals(Vector v) {
        return (Vector.equals(this.magnitude, v.magnitude))
                && Vector.equals(this, v);
    }

    private static boolean equals(double d1, double d2) {
        if (Math.abs(d1 - d2) < 0.0001) {
            return true;
        } else {
            return false;
        }
    }

    private static boolean equals(Vector v1, Vector v2) {
        if (v1.components.length != v2.components.length) {
            return false;
        }
        for (int i = 0; i < v1.components.length; i++) {
            if (!Vector.equals(v1.components[i], v2.components[i])) {
                return false;
            }
        }
        return true;
    }

    private void updateMagnitude() {
        double magnitude = 0;
        for (int i = 0; i < this.components.length; i++) {
            magnitude += Math.pow(this.components[i], 2);
        }
        this.magnitude = Math.sqrt(magnitude);
    }
}